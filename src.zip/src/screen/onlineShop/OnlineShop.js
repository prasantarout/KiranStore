import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const OnlineShop = () => {
  return (
    <View>
      <Text>OnlineShop</Text>
    </View>
  )
}

export default OnlineShop

const styles = StyleSheet.create({})