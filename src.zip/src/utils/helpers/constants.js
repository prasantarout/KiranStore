export default {
  BASE_URL: "https://bhanumart.com/dev",
  TOKEN: "TOKEN",
  REFRESH_TOKEN: "REFRESH_TOKEN",
  WHICHCREADS: "WHICHCREADS",
  // IMAGE_URL: "https://which-bar.dedicateddevelopers.us/storage/",
  FILTERVALUE: "FILTERVALUE",
};
